1. Conectse a su MySQL y ejecute el ddl siguiente:
    documentación/ddl-scripts.sql

2. Arranque Pentaho Kettle, vaya a “Edit” —-> “Editar el archivo kettle.properties”, y haga los cambios necesario en estas variables:
    - ETL_USER_NAME
    - ETL_USER_PASS
    - ETL_HOME_DIR
    - DIM_DATE_END  : Fijar la fecha 2020-12-31
    - DIM_DATE_START: Fijar la fecha 2010-01-01

3. Abrá el job de abajo y ejecutelo:
    main-job.kjb

4. Al finalizar el trabajo anterior, ejecute (run) la consulta de auditoria de aquí abajo y verifique que el conteo de registros origen y destino sean iguales:

   /* Fact Granuality */
   SELECT 'source_db.gs_orders' AS table_name
         , COUNT(*) AS cnt_num 
      FROM source_db.gs_orders
     UNION ALL  
    SELECT 'datamart_db.fact_orders' AS table_name
         , COUNT(*) AS cnt_num 
      FROM datamart_db.fact_orders;

  /* State Information */
  SELECT 'source' AS table_name, COUNT(*)
    FROM stage_db.stg_state
   UNION ALL  
  SELECT 'target' AS table_name, COUNT(*)
    FROM datamart_db.dim_geography;        
    
  /* Order Date and Ship Date */      
  SELECT 'source_db.gs_orders', SUM(CONVERT(DATE_FORMAT(`Ship Date`, '%Y%m%d'), signed integer) - CONVERT(DATE_FORMAT(`Order Date`, '%Y%m%d'), signed integer)) AS total_date_diff
    FROM source_db.gs_orders
   UNION ALL
  SELECT 'target_db.gs_orders', SUM(ship_date_skey - order_date_skey) AS total_date_diff
    FROM datamart_db.fact_orders ;   